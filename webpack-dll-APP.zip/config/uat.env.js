module.exports = {
	NODE_ENV: '"uat"'
}
