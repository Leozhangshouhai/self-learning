/**
* Created by Linyer on 2017/7/17.
*/
<template>
    <div class="fly-index">
        观影页面
       
    </div>
   
</template>

<script>
    import Vue from 'vue';
    import fly from "../assets/js/linyer";
   
    export default {
        data() {
            return {
                newuser: {
                    username: '',
                    password: ''
                },
                isLogin: false
            };
        },
       
        created() {
            const _self = this;
            _self.isLogin = _self.$store.state.is_login;
            console.log(_self.$store.state.is_login);
            setTimeout(()=>{
                _self.Indicator.close();
            },1000)
            //console.log(_self)
            //console.log(_self.chengdu)

//			fly.Axios({
//				url: _self.chengdu + _self.api.url,
//				data: {city_name: encodeURI("成都市")},
//				success: function (res) {
//					console.log(res)
//				}, error: function (err) {
//
//				}
//			})
        },
        methods: {}
    };
</script>

<style lang="scss">

</style>