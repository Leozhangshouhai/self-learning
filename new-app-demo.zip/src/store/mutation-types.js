//配置vuex调用的Mutations逻辑
export const ADD_ROUTE_CHAIN = "ADD_ROUTE_CHAIN"
export const POP_ROUTE_CHAIN = "POP_ROUTE_CHAIN"
export const SET_PAGE_DIRECTION = "SET_PAGE_DIRECTION"
export const IS_LOGIN = 'IS_LOGIN'