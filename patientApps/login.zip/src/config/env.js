/**
 * 配置编译环境和线上环境之间的切换
 * routerMode: 路由模式
 *
 */
// let routerMode = 'history';//history
let routerMode = 'hash';//history
export {
	routerMode
}
