/**
* Created by Linyer on 2017/7/17.
*/
<template>
    <div class="fly-index">
        <router-link to="/login">跳转去登录</router-link>
    </div>
</template>

<script>
	import Vue from 'vue';
	import fly from "../assets/js/linyer"
	export default {
		data() {
			return {};
		},
		created() {
			const _self = this;

		},
		methods: {}
	};
</script>

<style lang="scss" scoped>

</style>