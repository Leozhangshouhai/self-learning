/**
* Created by Linyer on 2017/7/21.
*/
<template>
<div >
    <input type="text" />
    <input type="text"/>
    <router-link to="/index">跳转去首页</router-link>
</div>
</template>

<script>
	import Vue from 'vue';
	
	export default {
		data() {
			return {};
		},
		created() {
			
		},
		methods: {}
	};
</script>

<style lang="scss" scoped>

</style>